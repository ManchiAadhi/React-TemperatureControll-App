import Temp from "./components/Temp";
function App() {
  return (
    <div  >
      <Temp/>
    </div>
  );
}
export default App;
